# AnilKumarRavuru

import string
key = int(input('Enter the key Value from 1 to 26: '))
input_file_name = input('Enter the name of the input file located in the same directory: ')
output_file_name = input('Enter the name of the output file: ')
alphabet = string.ascii_lowercase
cipher_alphabet = alphabet[key:]+alphabet[:key]
output_file = open(output_file_name, 'w')
with open(input_file_name, 'r') as lines:
	for line in lines:
		output_line = ''
		for x in line.lower():
			if x in alphabet:
				output_line += cipher_alphabet[alphabet.index(x)]
			else:
				output_line += x
		output_file.write(output_line)
lines.close()
output_file.close()
