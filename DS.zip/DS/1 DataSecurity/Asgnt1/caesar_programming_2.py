# AnilKumarRavuru

import string
import statistics

input_file_name = 'caesar1.txt'
alphabet = string.ascii_lowercase
e_pos = alphabet.index('e')
o_pos = alphabet.index('o')
t_pos = alphabet.index('t')
a_size = len(alphabet)
frequency = [0 for i in range(a_size)]
with open(input_file_name, 'r') as lines:
	for line in lines:
		for x in line.lower():
			if x in alphabet:
				frequency[alphabet.index(x)] += 1
frequency_mean = statistics.median(frequency)
key = 0
temp_max = 0
for temp in range(len(alphabet)):
	if frequency[(temp+e_pos) % a_size] + frequency[(temp+o_pos) % a_size] + frequency[(temp+t_pos) % a_size] > temp_max:
		key = temp
		temp_max = frequency[temp+e_pos] + frequency[temp+o_pos] + frequency[temp+t_pos]
print('\nFrequency of each letter before encoding...')
for _ in range(a_size):
	print(alphabet[_], ': ', frequency[_])
print('\nFrom these frequencies, Key: ', key)
print()
