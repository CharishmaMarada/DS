
# AnilKumarRavuru

import sysliteral_eval


def char_xor(a,b):
	return chr(ord(a) ^ ord(b))


def beautify_string(string):
	return string.replace('\\n', '\n').replace('\\t', '\t')


def main():
	if len(sys.argv) != 4:
		print('Error: 3 Arguments must be passed to run...')
		return
	key = sys.argv[1]
	input_file_name = sys.argv[2]
	output_file_name = sys.argv[3]
	with open(input_file_name, 'r') as input_file:
		content = input_file.read()
		encripted_content = ""
		char_count = 0
		x = 0
		while(x<len(content)):
			if content[x]=='\\':
				if content[x+1] == 'x':
					character = chr(int(content[x+2:x+4], 16))
					encripted_content += repr(char_xor(character, key[char_count%len(key)]))[1:-1]
					char_count += 1
					x+=3
				else:
					if content[x+1] == 't':
						character = chr(ord('\t'))
					elif content[x+1] == 'n':
						character = chr(ord('\n'))
					elif content[x+1] == 'r':
						character = chr(ord('\r'))
					encripted_content += repr(char_xor(character, key[char_count%len(key)]))[1:-1]
					char_count += 1
					x+=1
			else:
				character = content[x]
				encripted_content += repr(char_xor(character, key[char_count%len(key)]))[1:-1]
				char_count += 1
			x+=1
	output_file = open(output_file_name, 'w')
	output_file.write(beautify_string(encripted_content))
	output_file.close()

if __name__ == '__main__':
    main()
