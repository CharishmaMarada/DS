# AnilKumarRavuru

import sys


def byte_char_xor(byte, char):
	return int.from_bytes(byte, byteorder='big') ^ ord(char)


def main():
	if len(sys.argv) != 4:
		print('Error: 3 Arguments must be passed to run...')
		return
	key = sys.argv[1]
	input_file_name = sys.argv[2]
	output_file_name = sys.argv[3]

	with open(input_file_name, 'rb') as input_file:
		byte = input_file.read(1)
		char_count = 0
		encripted_data = []
		while byte:
			encripted_data += [byte_char_xor(byte, key[char_count % len(key)])]
			byte = input_file.read(1)
			char_count += 1
	encripted_byte_array = bytearray(encripted_data)
	output_file = open(output_file_name, 'wb')
	output_file.write(encripted_byte_array)
	output_file.close()

if __name__ == '__main__':
	main()
