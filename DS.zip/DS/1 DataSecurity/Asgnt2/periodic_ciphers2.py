# AnilKumarRavuru

import numpy as np

def detect_key(arr, m=5.0):
	diff = np.abs(arr - np.median(arr))
	positive_outliers = arr - np.median(arr)
	deviation = np.median(diff)
	s = positive_outliers / (deviation if deviation else 1.0)
	out_liers = s < m
	# out_liers_indexes = np.array(np.where(out_liers == False)) + 1
	return np.where(out_liers == False)[0][0] + 1


def integer_array_xor(arr1, arr2):
	return [arr1[i] ^ arr2[i] for i in range(min(len(arr1), len(arr2)))]


def main():
	input_file_name = input('Enter the input file name: ')
	with open(input_file_name, 'rb') as input_file:
		byte = input_file.read(1)
		content = []
		while byte:
			content += [int.from_bytes(byte, byteorder='big')]
			byte = input_file.read(1)
	shifts = [integer_array_xor(content[i:], content[:-i]).count(0) for i in range(1, min(100,len(content)-1))]
	# print(shifts)
	key = detect_key(shifts)
	print('Key value is: ', key)


if __name__ == '__main__':
	main()
