# AnilKumarRavuru

import numpy as np

def detect_key_length(arr, m=5.0):
	diff = np.abs(arr - np.median(arr))
	positive_outliers = arr - np.median(arr)
	deviation = np.median(diff)
	s = positive_outliers / (deviation if deviation else 1.0)
	out_liers = s < m
	# out_liers_indexes = np.array(np.where(out_liers == False)) + 1
	return int(np.where(out_liers == False)[0][0] + 1)


def integer_array_xor(arr1, arr2):
	return [arr1[i] ^ arr2[i] for i in range(min(len(arr1), len(arr2)))]


def most_frequent(arr):
	freq = {}
	for item in arr:
		if item in freq:
			freq[item] += 1
		else:
			freq[item] = 1
	final_item, final_freq = '', 0
	for item in freq:
		if freq[item] > final_freq:
			final_item, final_freq = item, freq[item]
	return final_item

def main():
	input_file_name = input('Enter the input file name: ')
	with open(input_file_name, 'rb') as input_file:
		byte = input_file.read(1)
		content = []
		while byte:
			content += [int.from_bytes(byte, byteorder='big')]
			byte = input_file.read(1)
	shifts = [integer_array_xor(content[i:], content[:-i]).count(0) for i in range(1, min(100, len(content)-1))]
	# print(shifts)
	key_length = detect_key_length(shifts)
	print('Period value is: ', key_length)
	frequency_array = ['' for i in range(key_length)]
	for j in range(key_length):
		temp_content = [content[i*key_length + j] for i in range(int(len(content)/key_length))]
		# print(temp_content)
		frequency_array[j] = most_frequent(temp_content)
		# print(frequency_array[j])
	key_character_arr = [chr(frequency_array[i] ^ ord(' ')) for i in range(key_length)]
	print('Key used for this encoding: ', ''.join(key_character_arr))


if __name__ == '__main__':
	main()
