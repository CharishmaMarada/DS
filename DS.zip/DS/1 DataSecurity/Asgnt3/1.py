# AnilKumarRavuru

import numpy as np
import itertools
from functools import reduce


def phi(arr):
	count = len(arr)
	freq = {}
	for x in range(count):
		if arr[x] in freq:
			freq[arr[x]] += 1
		else:
			freq[arr[x]] = 1
	ph = 0
	for x in freq:
		ph += (freq[x]/count)**2
	return ph

def main():
	encoded_data = open('adfgvx.encode', 'r').read()
	ph = phi(list(encoded_data))
	print ('Phi value for this text is: ', ph)

if __name__ == '__main__':
	main()