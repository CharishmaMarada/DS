# AnilKumarRavuru

import math
import itertools

def phi(arr):
	count = len(arr)
	freq = {}
	for x in range(count):
		if arr[x] in freq:
			freq[arr[x]] += 1
		else:
			freq[arr[x]] = 1
	ph = 0
	for x in freq:
		ph += (freq[x]/count)**2
	return ph

def formGrid(data, width):
	l = len(data)
	height = math.ceil(l/width)
	extra = l%width
	grid = [['' for i in range(width)] for j in range(height)]
	if extra == 0:
		for i in range(l):
			grid[i%height][int(i/height)] = data[i]
	else:
		for i in range(l):
			if i < extra*height:
				grid[i%height][int(i/height)] = data[i]
			else:
				grid[(i-extra*height)%(height - 1)][extra + int((i-extra*height)/(height-1))] = data[i]
	return grid

def permutGrid(grid, arr):
	height, width = len(grid), len(grid[0])
	if width != len(arr):
		print('width not equal to permutation length')
		return
	grid2 = [['' for i in range(width)] for j in range(height)]
	for i in range(width):
		for j in range(height):
			grid2[j][arr[i]] = grid[j][i]
	if grid[-1][-1] == '':
		for j in range(width):
			grid2[-1][j] = grid[-1][j]
	return grid2

def gridToList(grid):
	height, width = len(grid), len(grid[0])
	arr = []
	for i in range(0, height*width -1, 2):
		if grid[int(i/width)][i%width] == '':
			break
		arr += [grid[int(i/width)][i%width] + grid[int((i+1)/width)][(i+1)%width]]
	return arr

def main():
	encoded_data = open('adfgvx.encode', 'r').read()
	encoded_data = encoded_data[:-1]
	data_length = len(encoded_data)
	max_ph = 0
	max_per = []
	for perLen in range(3,10):
		cipher_grid = formGrid(encoded_data, perLen)
		perms = itertools.permutations(list(range(perLen)))
		for perm in perms:
			permuted_grid = permutGrid(cipher_grid, perm)
			cipher_letters = gridToList(permuted_grid)
			temp_ph = phi(cipher_letters)
			if temp_ph > max_ph:
				max_ph = temp_ph
				max_per = perm
		print('Max phi for block size', perLen, 'is ', max_ph, 'for permutation ', max_per)
	inverse_permutation = [ 0 for i in range(len(max_per))]
	for i in range(len(max_per)):
		inverse_permutation[max_per[i]] = i
	print('Permutation used to for this cipher is ', inverse_permutation)

if __name__ == '__main__':
	main()