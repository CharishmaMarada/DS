# AnilKumarRavuru

import math
import itertools
import re

def phi(arr):
	count = len(arr)
	freq = {}
	for x in range(count):
		if arr[x] in freq:
			freq[arr[x]] += 1
		else:
			freq[arr[x]] = 1
	ph = 0
	for x in freq:
		ph += (freq[x]/count)**2
	return ph

def most_frequent(arr):
	freq = {}
	for item in arr:
		if item in freq:
			freq[item] += 1
		else:
			freq[item] = 1
	final_item, final_freq = '', 0
	for item in freq:
		if freq[item] > final_freq:
			final_item, final_freq = item, freq[item]
	return final_item, final_freq

def formGrid(data, width):
	l = len(data)
	height = math.ceil(l/width)
	extra = l%width
	grid = [['' for i in range(width)] for j in range(height)]
	if extra == 0:
		for i in range(l):
			grid[i%height][int(i/height)] = data[i]
	else:
		for i in range(l):
			if i < extra*height:
				grid[i%height][int(i/height)] = data[i]
			else:
				grid[(i-extra*height)%(height - 1)][extra + int((i-extra*height)/(height-1))] = data[i]
	return grid

def permutGrid(grid, arr):
	height, width = len(grid), len(grid[0])
	if width != len(arr):
		print('width not equal to permutation length')
		return
	grid2 = [['' for i in range(width)] for j in range(height)]
	for i in range(width):
		for j in range(height):
			grid2[j][arr[i]] = grid[j][i]
	if grid[-1][-1] == '':
		for j in range(width):
			grid2[-1][j] = grid[-1][j]
	return grid2

def gridToList(grid):
	height, width = len(grid), len(grid[0])
	arr = []
	for i in range(0, height*width -1, 2):
		if grid[int(i/width)][i%width] == '':
			break
		arr += [grid[int(i/width)][i%width] + grid[int((i+1)/width)][(i+1)%width]]
	return arr

def main():
	encoded_data = open('adfgvx.encode', 'r').read()
	encoded_data = encoded_data[:-1]
	data_length = len(encoded_data)
	inverse_permutation = [5, 4, 3, 6, 8, 0, 1, 7, 2]
	cipher_grid = formGrid(encoded_data, len(inverse_permutation))
	permuted_grid = permutGrid(cipher_grid, inverse_permutation)
	cipher_letters = gridToList(permuted_grid)
	
	cipher_phi = phi(cipher_letters)

	min_diff_phi = 100
	min_diff_phi_start = 0
	alice_text = open('alice_in_wonderland.txt', 'r').read()
	alice_text = alice_text.lower()
	regex = re.compile('[^a-z0-9]')
	alice_text = regex.sub('', alice_text)
	for x in range(len(alice_text)-261):
		partial_text = alice_text[x:x+261]
		pos_phi = phi(list(partial_text))
		if abs(cipher_phi - pos_phi) < min_diff_phi:
			min_diff_phi = abs(cipher_phi - pos_phi)
			min_diff_phi_start = x
	# print(min_diff_phi, min_diff_phi_start)
	# print(cipher_letters)
	# print('-------')
	# print(list(alice_text[min_diff_phi_start:min_diff_phi_start+261]))
	print('\nText from the alice_in_wonderland.txt that is encrypted using cipher is: \n')
	print(alice_text[min_diff_phi_start:min_diff_phi_start+261])
	print()


if __name__ == '__main__':
	main()