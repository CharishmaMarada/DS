# AnilKumarRavuru

def phi(arr):
	count = len(arr)
	freq = {}
	for x in range(count):
		if x in freq:
			freq[x] += 1
		else:
			freq[x] = 1
	ph = 0
	for x in freq:
		ph += (x/count)**2
	return ph

def monomerPro(words_dict, word):
	if word not in words_dict:
		return 0
	return words_dict[word]/len(words_dict)

def pairPro(word_pair_dict, word1, word2):
	if (word1, word2) not in word_pair_dict:
		return 0
	return word_pair_dict[(word1, word2)] / len(word_pair_dict)

def main():
	words = {}
	word_pairs = {}
	content = open('alice_in_wonderland.txt', 'r').read().strip()
	words_list = content.split(' ')
	all_words = []
	for x in words_list:
		if x:
			if x in words:
				words[x] += 1
			else:
				words[x] = 1
			all_words += [x]
	for x in range(len(all_words)-1):
		if (all_words[x], all_words[x+1]) in word_pairs:
			word_pairs[(all_words[x], all_words[x+1])] += 1
		else:
			word_pairs[(all_words[x], all_words[x+1])] = 1
	print('\nPhi value of the text is ', phi(list(content)))
	print('\n')
	input_option = int(input('Enter\n1 to calculate Monomer Probability\n2 to calculate Pair Probability\n-1 to exit\n'))
	if input_option == -1:
		return
	while (True):
		if (input_option == 1):
			input_word = str(input('Enter the word to calculate the Monomer probability in alice_in_wonderland.txt:\n'))
			print (monomerPro(words, input_word))
		elif (input_option ==2):
			input_word1, input_word2 = map(str, input('Enter 2 space separated words to calculate the pair probability:\n').split(' '))
			print (pairPro(word_pairs, input_word1, input_word2))
		input_option = int(input('\nEnter\n1 to calculate Monomer Probability\n2 to calculate Pair Probability\n-1 to exit\n'))
		if input_option == -1:
			return


if (__name__ == '__main__'):
	main()
