# AnilKumarRavuru

import collections
import numpy as np
import string

def cipherTest(data):
	frequencies = dict(collections.Counter(data))
	freq_arr = list(frequencies.values())
	print('Number of distinct letters: ', len(freq_arr))
	print('Most frequent occurances: ', max(freq_arr))
	print('Least frequent occurances: ', min(freq_arr))
	print('Standard deviation of frequencies: ', np.std(freq_arr))
	psi = 0
	for x in frequencies:
		psi += ((frequencies[x]*1.0)/len(data))**2
	print('psi value of the text: ', psi)

def loadRotor(enter, exit, inv):
	global input_order
	global output_order
	count = 0
	for i in range(26):
		for j in range(26):
			if enter[i] == exit[j]:
				count += 1
		if inv and (enter[i] == exit[i]):
			return False
	if count != 26:
		return False
	input_order = ['' for i in range(26)]
	output_order = ['' for i in range(26)]
	if not inv:
		for i in range(26):
			input_order[i] = enter[i]
			output_order[i] = exit[i]
		return True
	input_order = [enter[i] for i in range(26)]
	output_order = ['' for i in range(26)]
	for i in range(26):
		if output_order[i] != '':
			continue
		if output_order[input_order.index(exit[i])] != '':
			continue
		output_order[i] = exit[i]
		for j in range(26):
			if input_order[j] == output_order[i]:
				if output_order[j] != '':
					continue
				output_order[j] = input_order[i]
				break
	for i in range(26):
		if output_order[i] == '':
			output_order[i] = input_order[i]
	return True

def decode(output_string, char, inv, off):
	if inv:
		return string.ascii_lowercase[output_string.index(char)]
	else:
		return string.ascii_lowercase[(output_string.index(char) + off) % 26]


def inverse_decode(output_string, char, inv, off):
	if inv:
		return output_string[string.ascii_lowercase.index(char)]
	else:
		return output_string[(string.ascii_lowercase.index(char) - off) % 26]

def main():
	global input_order
	global output_order
	enigma_code = open('cipher.problem.2', 'r').read()
	cipherTest(enigma_code)
	# output texts of all banks
	fixed_outputs = ['abcghidefjklpqrmnostxyzuvw', 'defghijklmnopqrstuvwxyzabc', 'zxbcdefghijklnmpqosrtuvway', 
					'zxbcdefghijklosrtuvwaynmpq', 'abcghidefjklpqrmnostxyzuvw', 'defghijklmnopqrstuvwxyzabc',
					'zxbcdefghijklnmpqosrtuvway', 'zxbcdefghijklosrtuvwaynmpq', 'abcghidefjklpqrmnostxyzuvw']
	# output text of bank 9
	reflector_output = 'zyabcdefghijklmnopqrstxwuv'
	loadRotor(string.ascii_lowercase, reflector_output, True)
	actual_reflector = ''.join(output_order)
	# print(actual_reflector)
	print()
	for key_size in range(1, 10):
		decoded_string = ''
		key_outputs = fixed_outputs[:key_size]
		for t in range(len(enigma_code)):
			letter = enigma_code[t]
			shifts = [int(t/(26**i)) % 26 for i in range(key_size)]
			# print(shifts)
			for x in range(key_size):
				letter = inverse_decode(key_outputs[x], letter, True, 0)
			letter = decode(actual_reflector, letter, True, 0)
			for x in range(key_size):
				letter = decode(key_outputs[-x-1], letter, False, shifts[-x-1])
			decoded_string += letter
		print('For key lenght: ', key_size, '\nTranslation message: ', decoded_string)
		cipherTest(decoded_string)
		print('****************************************************************************\n')


if __name__ == '__main__':
	main()