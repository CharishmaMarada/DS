# AnilKumarRavuru

import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None

def getPosWordFromName(name):
	name = name.decode("utf-8")
	pos = int(name.split('.')[1])
	word = name.split('.')[2]
	return pos, word

with pysftp.Connection('snowball.cs.gsu.edu', username='aravuru1', password='Vedavathi2', cnopts=cnopts) as sftp:
	message_files = sftp.execute('cd /tmp ; ls aravuru1*')
	final_message = ['' for i in range(len(message_files))]
	if len(message_files) == 0:
		print('No Message found!!!')
	else:
		for message in message_files:
			pos, word = getPosWordFromName(message)
			final_message[pos] = word
		print(' '.join(final_message))
