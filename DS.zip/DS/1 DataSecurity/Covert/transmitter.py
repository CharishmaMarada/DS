# AnilKumarRavuru

import pysftp
cnopts = pysftp.CnOpts()
cnopts.hostkeys = None

with pysftp.Connection('snowball.cs.gsu.edu', username='aravuru1', password='Vedavathi2', cnopts=cnopts) as sftp:
    basic_command = 'cd /tmp ; touch aravuru1.'
    word_count = 0
    with open('input.txt', 'r') as lines:
    	for line in lines:
    		words = line.split(' ')
    		for word in words:
    			command = basic_command + str(word_count) + '.' + word + '.txt'
    			sftp.execute(command)
    			word_count += 1
