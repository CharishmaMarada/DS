# AnilKumarRavuru

import sys
import os


def main():
	command1 = "./a.out {} < classcipher2 > sample.txt"
	with open('/usr/share/dict/words') as fp:
		for line in fp:
			not_this_key = False
			final_command = command1.format(line[:-1])
			os.system(final_command)
			# print(final_command)
			with open('sample.txt', 'rb') as sample_file:
				byte = sample_file.read(1)
				i = 0
				while byte:
					i+=1
					its_ascii = int.from_bytes(byte, byteorder='big')
					if not (its_ascii > 31 and its_ascii < 125):
						not_this_key = True
						break
					if i==20:
						print('the key used is :', line)		# iodinium (Yeyyyyyyyyyyy)
						return
					byte = sample_file.read(1)


if __name__ == '__main__':
	main()
