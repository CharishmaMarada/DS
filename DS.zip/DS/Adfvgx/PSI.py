from collections import Counter
from sys import argv
import math

with open(argv[1], 'r') as file1:
    text = file1.read().replace('\n', '').replace(" ", "")
text = (''.join(c for c in text if c.isalpha()))
text = text.lower()
file1.close()


def getPSI(freq):
    psi = 0
    for c in freq:
        psi = psi + (freq[c] * freq[c])
    return psi

def getFrequencies(count,size):
    charFreqencies = {}
    for c in count:
        charFreqencies[c] = (count[c] / size)
    return charFreqencies



singleCharCount = Counter(c for c in text if c.isalpha())
singleCharFreq = getFrequencies(singleCharCount,len(text))
psiVal = getPSI(singleCharFreq)
print("Psi value for single letters: "+ str(psiVal))

totalCount = len(text) / 2
if(not totalCount.is_integer()):
    decimal, whole = math.modf(totalCount)
    totalCount = whole
    size = len(text)-1
else:
    size = len(text)

countDoubleChar = {}
for element in range(0, size, 2) :
    letter = "".join(text[element : element + 2])
    if letter in countDoubleChar:
       countDoubleChar[letter] += 1
    else:
       countDoubleChar[letter] = 1

doubleCharFreq = getFrequencies(countDoubleChar,totalCount)

doublePSIVal = getPSI(doubleCharFreq)
print("Psi value for a pair of letters: ",doublePSIVal)
