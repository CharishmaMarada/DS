from collections import Counter
from sys import argv
import math

with open(argv[1], 'r') as file1:
    text = file1.read().replace('\n', '').replace(" ", "")
text = (''.join(c for c in text if c.isalpha()))
text = text.lower()
file1.close()

def psi(freq):
    psiVal = 0
    for c in freq:
        psiVal = psiVal + (frequencies[c] * frequencies[c])
    return psiVal

def getFrequency(count,size):
    char_freqencies = {}
    for c in count:
        char_freqencies[c] = (count[c] / size)
    return char_freqencies


singleCount = Counter(c for c in text if c.isalpha())
print(singleCount)
singleFreqencies = getFrequency(singleCount,len(text))
psiVal = psi(singleFreqencies)
print("Psi value is "+ str(psiVal))

