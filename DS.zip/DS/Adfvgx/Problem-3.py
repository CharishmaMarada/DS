
from sys import argv
from itertools import permutations

with open(argv[1], 'r') as file1:
    text = file1.read().replace('\n', '')
file1.close()

maxDoublePSIVal = [0, 0]
maxPermMsg = ""
maxDoublePSITup = []
maxDlublePSIFreq = {}
def getPSI(doubleCharFreq):
    psiVal = 0
    for c in range(0,len(doubleCharFreq)):
        psiVal = psiVal + (doubleCharFreq[c] * doubleCharFreq[c])
    return psiVal

def getCount(message,limit):
    doubleCharCount = {}
    for i in range(0, limit, 2):
        c = "".join(message[i: i + 2])
        if c in doubleCharCount:
            doubleCharCount[c] += 1
        else:
            doubleCharCount[c] = 1
    return doubleCharCount


for block in range(3, 8):
    l = list(permutations(range(0, block)))
    textL = [text[i: i + block] for i in range(0, len(text), block)]

    for perm in l:
        permMessage = ""
        for temp in textL:
            if len(temp) == block :
                for i in range(0, block):
                    permMessage += temp[perm[i]]
            else:
                permMessage += temp

        totalCount = len(permMessage) / 2
        whole_number = int(totalCount)
        if totalCount.is_integer():
            limit = len(permMessage)
        else:
            limit = len(permMessage) - 1

        totalCount = whole_number
        doubleCharCount = getCount(permMessage, limit)
        doubleCharFreq = []
        for c in doubleCharCount:
            doubleCharFreq.append(doubleCharCount[c] / totalCount)
        doubleCharPSIVal = getPSI(doubleCharFreq)
        if maxDoublePSIVal[1] < doubleCharPSIVal :
            maxDoublePSIVal[0] = permutation
            maxDoublePSIVal[1] = doubleCharPSIVal
            maxDlublePSIFreq = doubleCharFreq
            maxPermMsg = permMessage

print("max double Psi value: " + str(maxDoublePSIVal[1]))
print("permutation: "+str(maxDoublePSIVal[0]))
print("Permuted message value: " + maxPermMsg)

with open("adfgvx_permuted.encode", 'w+') as file2:
   file2.write(maxPermMsg)
file2.close()
