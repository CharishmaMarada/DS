from sys import argv

with open(argv[1], 'r') as file1:
    text = file1.read().replace('\n', '').replace(" ", "")
text = (''.join(c for c in text if c.isalpha())).lower()
file1.close()


with open(argv[2], 'r') as file2:
    permuted = file2.read().replace('\n', '').replace(" ", "")
permuted = (''.join(c for c in permuted if c.isalpha())).lower()
file2.close()


charCount = {}
pattern = {}
pos = 0
for i in range(0, len(permuted), 2):
    c = "".join(permuted[i: i + 2])
    if c in charCount:
        charCount[c] += 1
        pattern[c].append(pos)
    else:
        charCount[c] = 1
        posList = list()
        posList.append(pos)
        pattern[c] = posList
    pos += 1

adfgvxLength = len(permuted)
lenAlice = len(text)
start = 0
end = int(adfgvxLength / 2)
counter = False

pattern_matches = []

while (counter == False and end != lenAlice + 1):
    aliceSub = text[start:end]
    pattern = {}
    aliceCount = {}
    pos = 0
    for iteration in range(0, len(aliceSub)):
        letter = aliceSub[iteration]
        if letter in aliceCount:
            aliceCount[letter] += 1
            pattern[letter].append(pos)
        else:
            aliceCount[letter] = 1
            posList = list()
            posList.append(pos)
            pattern[letter] = posList
        pos += 1

    start += 1
    end += 1

    freq_total_count = len(pattern)
    freq_match_count = 0


    for patrn in pattern:
        patterns = pattern[patrn]
        for patrn1 in pattern:
            pattern = pattern[patrn1]
            if patterns == pattern:
                freq_match_count += 1

    if freq_total_count == freq_match_count:
        print("there is match")
        print(pattern)
        print(pattern)
        print("alice substring is " + aliceSub)
        counter = True
    with open("alice_substring.txt", 'w+') as output_data_file:
        output_data_file.write(aliceSub)






