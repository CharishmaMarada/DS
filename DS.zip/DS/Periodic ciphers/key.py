import sys
import period

def mostCommon(s):
    l = []
    maxV = 0
    cur = ""
    for c in s:
        if c not in l:
            list.append(c)
            count = s.count(c)
            if (count > maxV):
                maxVal = count
                cur = c
    return cur

file1 = open(sys.argv[1], "rb")
s = file1.read().decode('UTF-8')
p = period.period(s)
key = ""
for i in range(p):
    cur = ""
    for j in range(len(s)):
        if (j%p == i):
            cur += s[j]
    maxChar = mostCommon(cur)
    key += chr(ord(" ") ^ ord(maxChar))
print(key)