import sys

def kappaScore(a, b):
    l = len(a)
    if len(b) < l:
        l = len(b)
    k = 0
    for i in range(0,l):
        if a[i] == b[i]:
            k += 1
    return k

def getPeriod(kappalist):
    count = 0
    total = 0
    periodlist = []
    for i in range(1,len(kappalist)):
        count += 1
        if(kappalist[i]==1):
            periodlist += [count]
            count = 0
    total = sum(periodlist)
    return round(total/len(periodlist))

def period(text):
    kappaVal = []
    for i in range(len(text)):
        val = kappaScore(text[i:],text)
        if(val >= 1000):
            kappaVal += [1]
        else:
            kappaVal += [0]
    return getPeriod(kappaVal)
