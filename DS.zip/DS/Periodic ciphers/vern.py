import sys
def xor(text,key):
    res = ''
    for i in range(0,len(text)):
        res += chr(ord(text[i]) ^ ord(key[i%len(key)]))
    return res
	
key = str(sys.argv[1])
file1 = open(sys.argv[2], "rb")
text = file1.read().decode('UTF-8')
file2 = open(sys.argv[3], "wb")
res = bytes(xor(text,key),'UTF-8')
file2.write(res)
file1.close()
file2.close()