#!/usr/bin/python

import rand_int
import sys

offset = 0
if len(sys.argv) > 1:
   offset = int(sys.argv[1])

rng = rand_int.mitchel_moore( 127)

for i in range(0,offset):
   x = rng.next()

for line in sys.stdin:
#  chars = list(line)
  chars = map( lambda x: chr((ord(x) -rng.next()+127)%127),list(line) )
  sys.stdout.write( ''.join(chars)) 
#  print chars
