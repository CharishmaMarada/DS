from socket import *
import sys
import subprocess
import threading

global flag
global host
global port
global protocol

def acceptData():
    flag = sys.argv[1]
    host = sys.argv[2]
    port = sys.argv[3]
    protocol = sys.argv[4]
    return flag,host,port,protocol

def clientTCP(host,port):
    print("TCP Client is up")
    clientSocket = socket(AF_INET, SOCK_STREAM)
    try:
        clientSocket.connect((host, port))
        print("Enter a message: ")
        sentence=sys.stdin.readline(1000)
        clientSocket.send(sentence.encode())
        sentencefromserver = clientSocket.recv(1024)
        print("ACK")
        print('TCP Server says: ', sentencefromserver.decode())
        clientSocket.close()
    except Error as e:
        print(e)
        port += 1

def clientUDP(host,port):
    print("UDP client is up")
    clientSocket = socket(AF_INET, SOCK_DGRAM)
    print("Enter a message: ")
    message = sys.stdin.readline(1000)
    serveraddressport=(host,port)
    clientSocket.sendto(message.encode(),serveraddressport)
    sentencefromserver, serverAddress = clientSocket.recvfrom(2048)
    print("ACK")
    print('UDP Server says:',sentencefromserver.decode())
    clientSocket.close()

def serverTCP(serverport):
    serverSocket = socket(AF_INET, SOCK_STREAM)
    try:
        serverSocket.bind(('', serverport))
        serverSocket.listen(1)
        print("TCP server is up: ")
        while True:
            connectionSocket, addr = serverSocket.accept()
            Messagefromclient = connectionSocket.recv(1024).decode()
            print("Client is saying: ")
            sys.stdout.write(str(Messagefromclient))
            connectionSocket.send(Messagefromclient.encode())
            connectionSocket.close()
    except:
        serverSocket.close()

def serverUDP(serverport):
    print("UDP LISTENER STARTED")
    serverSocket = socket(AF_INET, SOCK_DGRAM)
    try:
        serverSocket.bind(('',serverport))
        print("UDP server is up")
        while True:
            message, clientAddress = serverSocket.recvfrom(2048)
            Messagefromclient = message.decode()
            print("Client is saying: ")
            sys.stdout.write(str(Messagefromclient))
            serverSocket.sendto(Messagefromclient.encode(),clientAddress)
    except:
        serverSocket.close()

if __name__ == "__main__":
    flag,host,port,protocol = acceptData()
    port=int(port)
    if(flag=='-S' or flag=='-s'):
        print("Client has been started.")
        if(protocol == 'tcp'):
            clientTCP(host,port)
        else:
            clientUDP(host,port)
    elif(flag=='-L' or flag=='-l'):
        print("Server has been started")
        if(protocol == 'tcp'):
            serverTCP(port)
        else:
            serverUDP(port)


