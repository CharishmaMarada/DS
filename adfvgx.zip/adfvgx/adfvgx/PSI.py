from collections import Counter
from sys import argv
import math

with open(argv[1], 'r') as input_data_file:
    text = input_data_file.read().replace('\n', '').replace(" ", "")
text = (''.join(character for character in text if character.isalpha()))
text = text.lower()
input_data_file.close()

#finding psi

def find_psi(frequencies):
    psi = 0
    for letter in frequencies:
        psi = psi + (frequencies[letter] * frequencies[letter])
    return psi

def find_frequencies(count,size):
    letter_freqencies = {}
    for letter in count:
        letter_freqencies[letter] = (count[letter] / size)
    return letter_freqencies


# here we are counting single letters

single_char_count = Counter(character for character in text if character.isalpha())


# Here we are finding the frequencies of single letters

single_char_freqencies = find_frequencies(single_char_count,len(text))

# Here we are finding the psi value for each single using frequency value we got

psi_val = find_psi(single_char_freqencies)
print("psi valiue for single letter is "+ str(psi_val))



# Here we are finding the double letter count
total_count = len(text) / 2
if(not total_count.is_integer()):
    decimal, whole = math.modf(total_count)
    total_count = whole
    size = len(text)-1
else:
    size = len(text)



count_double_char = {}
for element in range(0, size, 2) :
    letter = "".join(text[element : element + 2])
    if letter in count_double_char:
       count_double_char[letter] += 1
    else:
       count_double_char[letter] = 1

# here we are finding double letter freqencies
double_letter_freqencies = find_frequencies(count_double_char,total_count)

#here we are finding the psi value of double letters
double_psi_value = find_psi(double_letter_freqencies)
print("psi value for double letters is ",double_psi_value)
