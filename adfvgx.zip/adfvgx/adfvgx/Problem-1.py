from collections import Counter
from sys import argv
import math

with open(argv[1], 'r') as input_data_file:
    text = input_data_file.read().replace('\n', '').replace(" ", "")
text = (''.join(character for character in text if character.isalpha()))
text = text.lower()
input_data_file.close()

#finding psi
def psi(frequencies):
    psi_value = 0
    for letter in frequencies:
        psi_value = psi_value + (frequencies[letter] * frequencies[letter])
    return psi_value

def find_frequency(count,size):
    letter_freqencies = {}
    for letter in count:
        letter_freqencies[letter] = (count[letter] / size)
    return letter_freqencies

# here we are counting single letters

single_char_count = Counter(character for character in text if character.isalpha())
print(single_char_count)

# Here we are finding the frequencies of single letters

single_char_freqencies = find_frequency(single_char_count,len(text))

# Here we are finding the psi value for each single using frequency value we got

psi_val = psi(single_char_freqencies)
print("Psi value is "+ str(psi_val))

