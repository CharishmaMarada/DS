
from sys import argv
from itertools import permutations

with open(argv[1], 'r') as input_data_file:
    text = input_data_file.read().replace('\n', '')
input_data_file.close()

max_double_psi_value = [0, 0]
max_permuted_message = ""
max_double_psi_tuple = []
max_double_psi_frequencies = {}

def find_count(message,limit):
    double_char_count = {}
    for iteration in range(0, limit, 2):
        letter = "".join(message[iteration: iteration + 2])
        if letter in double_char_count:
            double_char_count[letter] += 1
        else:
            double_char_count[letter] = 1
    return double_char_count


def find_psi(double_char_freqency):
    psi_value = 0
    for letter in range(0,len(double_char_freqency)):
        psi_value = psi_value + (double_char_freqency[letter] * double_char_freqency[letter])
    return psi_value

for block in range(3, 8):
    permutatiion_list = list(permutations(range(0, block)))

     #Split the input message in block

    text_list = [text[i: i + block] for i in range(0, len(text), block)]

    for permutation in permutatiion_list:
        message_permuted = ""
        # finding the permuted message
        for data_chunk in text_list:
            if len(data_chunk) == block :
                for i in range(0, block):
                    message_permuted += data_chunk[permutation[i]]
            else:
                message_permuted += data_chunk

        # Calculate PSI for permuted message
        total_count = len(message_permuted) / 2
        whole_number = int(total_count)
        if total_count.is_integer():
            limit = len(message_permuted)
        else:
            limit = len(message_permuted) - 1

        total_count = whole_number
        double_char_count = find_count(message_permuted, limit)
        double_char_freqency = []
        for letter in double_char_count:
            double_char_freqency.append(double_char_count[letter] / total_count)

        double_letter_psi_value = find_psi(double_char_freqency)


        if max_double_psi_value[1] < double_letter_psi_value :
            max_double_psi_value[0] = permutation
            max_double_psi_value[1] = double_letter_psi_value
            max_double_psi_frequency = double_char_freqency
            max_permuted_message = message_permuted


print("maximum double psi value = " + str(max_double_psi_value[1]))
print("permutation is "+str(max_double_psi_value[0]))
print("Permuted message value is " + max_permuted_message)

with open("adfgvx_permuted.encode", 'w+') as output_data_file:
   output_data_file.write(max_permuted_message)
output_data_file.close()
