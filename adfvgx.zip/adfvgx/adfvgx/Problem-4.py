from sys import argv

# reading first file
with open(argv[1], 'r') as input_file_one:
    text = input_file_one.read().replace('\n', '').replace(" ", "")
text = (''.join(character for character in text if character.isalpha())).lower()
input_file_one.close()

# reading second file

with open(argv[2], 'r') as input_file_two:
    permuted = input_file_two.read().replace('\n', '').replace(" ", "")
permuted = (''.join(character for character in permuted if character.isalpha())).lower()
input_file_two.close()


letter_count = {}
pattern = {}
position = 0
for iteration in range(0, len(permuted), 2):
    letter = "".join(permuted[iteration: iteration + 2])
    if letter in letter_count:
        letter_count[letter] += 1
        pattern[letter].append(position)
    else:
        letter_count[letter] = 1
        position_list = list()
        position_list.append(position)
        pattern[letter] = position_list
    position += 1

adfgvx_length = len(permuted)
length_alice = len(text)
start_position = 0
end_position = int(adfgvx_length / 2)
counter = False

pattern_matches = []

while (counter == False and end_position != length_alice + 1):
    alice_substring = text[start_position:end_position]
    alice_pattern = {}
    alice_count = {}
    position = 0
    for iteration in range(0, len(alice_substring)):
        letter = alice_substring[iteration]
        if letter in alice_count:
            alice_count[letter] += 1
            alice_pattern[letter].append(position)
        else:
            alice_count[letter] = 1
            position_list = list()
            position_list.append(position)
            alice_pattern[letter] = position_list
        position += 1

    start_position += 1
    end_position += 1

    freq_total_count = len(pattern)
    freq_match_count = 0


    for patrn in pattern:
        patterns = pattern[patrn]
        for patrn1 in alice_pattern:
            alice_patterns = alice_pattern[patrn1]
            if patterns == alice_patterns:
                freq_match_count += 1

    if freq_total_count == freq_match_count:
        print("there is match")
        print(alice_pattern)
        print(pattern)
        print("alice substring is " + alice_substring)
        counter = True
    with open("alice_substring.txt", 'w+') as output_data_file:
        output_data_file.write(alice_substring)






