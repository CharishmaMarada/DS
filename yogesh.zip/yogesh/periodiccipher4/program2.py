import sys
import matplotlib.pyplot as plot

with open(sys.argv[1], 'r') as input_file:
    input_data = input_file.read()
input_file.close()
max_period = 50
avg_ic_dic = {}
ic = 0
for period in range(1, max_period):
    N = avg_ic = total_ic_value = 0.0
    for x_value in range(period):
        shifted= ""
        for y_value in range(0,len(input_data[x_value:]), period):
            shifted += (input_data[x_value:][y_value])
        shifted_string_length = len(shifted)
        N = shifted_string_length * (shifted_string_length - 1)
        total_letter_count = 0
        for character in set(shifted):
            letter_count = shifted.count(character)
            total_letter_count += letter_count * (letter_count - 1)
        ic = total_letter_count / N
        total_ic_value += ic
    avg_ic_value = total_ic_value/period
    avg_ic_dic[period] = avg_ic_value


plot.plot(list(avg_ic_dic.keys()), list(avg_ic_dic.values()))
plot.xlabel('Period-x')
plot.ylabel('IC Value-y')
plot.show()


