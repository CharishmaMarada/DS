
import sys
import collections

with open(sys.argv[1], 'r') as input_data_file:
    text = input_data_file.read()
input_data_file.close()

period_value = int(sys.argv[2])
periodic_values = []
for x_value in range(period_value):
    period_string = ""
    for y_value in range(0, len(text[x_value:]), period_value):
        period_string += (text[x_value:][y_value])
    periodic_values.append(period_string)

key_value = ""

for value in periodic_values:
    key_value += chr(ord(collections.Counter(value).most_common(1)[0][0]) ^ ord(' '))

print("key value is " + str(key_value))