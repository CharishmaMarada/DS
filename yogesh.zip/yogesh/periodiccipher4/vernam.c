#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char * argv[]) {
	
  char * input_file, * input_key, * output_file;
  input_key = argv[1];
  input_file = argv[2];
  output_file = argv[3];

  FILE * input_file_pointer = fopen(input_file, "rb");
  if (input_file_pointer == NULL) {
    perror("Please check the file, there is an issue with it");
    exit(1);
  }
  FILE * output_file_pointer = fopen(output_file, "wb");
  if (output_file_pointer == NULL) {
    perror("Please check the file, there is an issue with it");
    exit(1);
  }
  char letter, xor_value;
  int index = 0;
  int key_length = strlen(input_key);

  while ((letter = fgetc(input_file_pointer)) != EOF) {
    xor_value = (letter ^ input_key[index]);
    fputc(xor_value, output_file_pointer);
    index = index + 1;
    xor_value = ' ';
    if (index == key_length) {
      index = 0;
    }

  }
  fclose(input_file_pointer);
  fclose(output_file_pointer);

  return 0;
}
